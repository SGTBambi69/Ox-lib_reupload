export const setClipboard = (value: string) => exports.ox_lib.setClipboard(value);
