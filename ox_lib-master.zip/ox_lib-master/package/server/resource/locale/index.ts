export const getServerLocale = (): string => exports.ox_lib.getServerLocale();
