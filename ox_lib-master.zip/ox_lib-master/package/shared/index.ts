export * from './resource';
